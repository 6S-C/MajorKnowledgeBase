# 第 5 章 Starter：Coding Agent

## 目的

检查完整 Coding Agent 的工具注册、离线启动和跨平台测试情况，理解“读取—修改—执行—验证—纠错”的闭环。

## 结果

- `main.py --list-tools` 成功加载 16 个工具，包括 Bash、Glob、Grep、LS、Read、Edit、MultiEdit、Write、NotebookEdit、TodoWrite、WebFetch 和后台任务管理等。
- 完整测试共 165 项，161 项通过、4 项失败，通过率 97.6%。
- 失败集中在：后台任务未继承持久环境变量、`true` 命令退出码、持久 Shell 在中文路径下定位失败、500 ms 子秒超时用例。

## 分析

四项失败都位于 Windows Shell 适配层，错误输出中出现中文路径乱码，说明 Shell 类型、字符编码、命令语义和超时精度都是 Coding Agent Harness 的组成部分。只验证模型是否能生成补丁，不能代表一个编码 Agent 已经可靠。

## 结论边界

本周进行了离线工具加载和测试，没有配置该项目支持的 Anthropic/OpenAI/OpenRouter 密钥，因此没有运行真实模型驱动的端到端编码任务。

## 证据

- [16 个工具清单](../../关键证据/Coding-Agent/01-list-tools.txt)
- [完整测试日志](../../关键证据/Coding-Agent/02-tests-workspace-tmp.txt)

