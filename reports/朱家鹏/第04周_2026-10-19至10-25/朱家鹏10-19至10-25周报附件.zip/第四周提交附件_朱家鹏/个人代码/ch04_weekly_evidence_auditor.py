"""Audit a weekly experiment evidence folder and emit a compact report.

The function can be called directly by an agent tool registry, while the CLI is
useful for repeatable weekly checks.  It intentionally reads files only.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any


SECRET_PATTERNS = {
    "api_key_assignment": re.compile(
        r"(?i)(?:api[_-]?key|secret|token)\s*[:=]\s*['\"]?[A-Za-z0-9_\-]{16,}"
    ),
    "openai_style_key": re.compile(r"\bsk-[A-Za-z0-9_-]{16,}\b"),
}
TEXT_SUFFIXES = {".md", ".txt", ".json", ".csv", ".log", ".py", ".yaml", ".yml"}


@dataclass
class EvidenceAudit:
    root: str
    file_count: int
    total_bytes: int
    valid_json: int
    invalid_json: list[str]
    secret_hits: list[dict[str, Any]]
    extension_counts: dict[str, int]
    sha256: dict[str, str]

    @property
    def passed(self) -> bool:
        return not self.invalid_json and not self.secret_hits and self.file_count > 0


TOOL_DEFINITION = {
    "name": "audit_weekly_evidence",
    "description": "检查周报实验证据目录中的文件、JSON有效性、敏感信息和校验值。",
    "parameters": {
        "type": "object",
        "properties": {
            "root": {"type": "string", "description": "待检查的证据目录"},
        },
        "required": ["root"],
    },
}


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def audit_weekly_evidence(root: str | Path) -> dict[str, Any]:
    """Return a JSON-serializable audit result for *root*."""
    base = Path(root).resolve()
    if not base.is_dir():
        raise ValueError(f"证据目录不存在或不是目录：{base}")

    files = sorted(path for path in base.rglob("*") if path.is_file())
    invalid_json: list[str] = []
    secret_hits: list[dict[str, Any]] = []
    extension_counts: dict[str, int] = {}
    hashes: dict[str, str] = {}

    for path in files:
        relative = path.relative_to(base).as_posix()
        suffix = path.suffix.lower() or "<无扩展名>"
        extension_counts[suffix] = extension_counts.get(suffix, 0) + 1
        hashes[relative] = _sha256(path)

        if suffix == ".json":
            try:
                json.loads(path.read_text(encoding="utf-8-sig"))
            except (OSError, UnicodeError, json.JSONDecodeError):
                invalid_json.append(relative)

        if suffix in TEXT_SUFFIXES:
            try:
                text = path.read_text(encoding="utf-8-sig", errors="replace")
            except OSError:
                continue
            for name, pattern in SECRET_PATTERNS.items():
                matches = list(pattern.finditer(text))
                if matches:
                    secret_hits.append(
                        {"file": relative, "pattern": name, "count": len(matches)}
                    )

    audit = EvidenceAudit(
        root=str(base),
        file_count=len(files),
        total_bytes=sum(path.stat().st_size for path in files),
        valid_json=sum(1 for path in files if path.suffix.lower() == ".json")
        - len(invalid_json),
        invalid_json=invalid_json,
        secret_hits=secret_hits,
        extension_counts=dict(sorted(extension_counts.items())),
        sha256=hashes,
    )
    result = asdict(audit)
    result["passed"] = audit.passed
    return result


def to_markdown(result: dict[str, Any]) -> str:
    status = "通过" if result["passed"] else "需检查"
    lines = [
        "# 周报证据审计结果",
        "",
        f"- 状态：**{status}**",
        f"- 文件数：{result['file_count']}",
        f"- 总大小：{result['total_bytes']} bytes",
        f"- 有效 JSON：{result['valid_json']}",
        f"- 无效 JSON：{len(result['invalid_json'])}",
        f"- 敏感信息命中：{len(result['secret_hits'])}",
        "",
        "## 文件类型",
        "",
        "| 扩展名 | 数量 |",
        "| --- | ---: |",
    ]
    lines.extend(
        f"| {suffix} | {count} |"
        for suffix, count in result["extension_counts"].items()
    )
    return "\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser(description="检查周报实验证据目录")
    parser.add_argument("root", help="待检查的目录")
    parser.add_argument("--json-out", type=Path)
    parser.add_argument("--md-out", type=Path)
    args = parser.parse_args()

    result = audit_weekly_evidence(args.root)
    json_text = json.dumps(result, ensure_ascii=False, indent=2)
    print(json_text)
    if args.json_out:
        args.json_out.parent.mkdir(parents=True, exist_ok=True)
        args.json_out.write_text(json_text + "\n", encoding="utf-8")
    if args.md_out:
        args.md_out.parent.mkdir(parents=True, exist_ok=True)
        args.md_out.write_text(to_markdown(result), encoding="utf-8")


if __name__ == "__main__":
    main()
